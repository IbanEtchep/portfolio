package com.example.easyfood42.modele;

import android.content.Context;
import android.database.Cursor;

import com.example.easyfood42.controleur.Contenir;

import java.util.Date;

public class ContenirDAO {
    private static String base = "BDeasyfood";
    private static int version = 1;
    private BdSQLiteOpenHelper accesBD;

    public ContenirDAO(Context ct){
        accesBD = new BdSQLiteOpenHelper(ct, base, null, version);
    }

    public Contenir getContenirByIdC(long idC){
        Contenir unContenir = null;
        Cursor curseur;
        curseur = accesBD.getReadableDatabase().rawQuery("select * from contenir where idC="+idC+";",null);
        if (curseur.getCount() > 0) {
            curseur.moveToFirst();
            unContenir = new Contenir(idC,curseur.getLong(1),curseur.getInt(2));
        }
        return unContenir;
    }
}
