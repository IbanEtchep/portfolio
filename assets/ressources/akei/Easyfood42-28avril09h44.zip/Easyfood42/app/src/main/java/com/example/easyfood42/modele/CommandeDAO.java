package com.example.easyfood42.modele;

import android.content.Context;
import android.database.Cursor;

import com.example.easyfood42.controleur.Commande;

import java.util.Date;

public class CommandeDAO {

    private static String base = "BDeasyfood";
    private static int version = 1;
    private BdSQLiteOpenHelper accesBD;

    public CommandeDAO(Context ct){
        accesBD = new BdSQLiteOpenHelper(ct, base, null, version);
    }

    public Commande getCommandeByIdC(long idC){
        Commande uneCommande = null;
        Cursor curseur;
        curseur = accesBD.getReadableDatabase().rawQuery("select * from commande where idC="+idC+";",null);
        if (curseur.getCount() > 0) {
            curseur.moveToFirst();
            uneCommande = new Commande(idC, new Date(curseur.getLong(1)),curseur.getString(2),new Date(curseur.getLong(3)),curseur.getString(4),Boolean.parseBoolean(curseur.getString(5)),curseur.getLong(6));
        }
        return uneCommande;
    }

}
