package com.example.easyfood42.modele;

import android.content.Context;
import android.database.Cursor;

import com.example.easyfood42.controleur.Plat;

public class PlatDAO {

    private static String base = "BDeasyfood";
    private static int version = 1;
    private BdSQLiteOpenHelper accesBD;

    public PlatDAO(Context ct){
        accesBD = new BdSQLiteOpenHelper(ct, base, null, version);
    }

    public Plat getPlatByIdP(long idP){
        Plat unPlat = null;
        Cursor curseur;
        curseur = accesBD.getReadableDatabase().rawQuery("select * from plat where idP="+idP+";",null);
        if (curseur.getCount() > 0) {
            curseur.moveToFirst();
            unPlat = new Plat(idP,curseur.getString(1),curseur.getLong(2),curseur.getLong(3),Boolean.parseBoolean(curseur.getString(4)),curseur.getString(5),curseur.getString(6),curseur.getLong(7),curseur.getLong(8));
        }
        return unPlat;
    }
}
